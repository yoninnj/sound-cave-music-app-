from django.apps import AppConfig


class MusicRoomConfig(AppConfig):
    name = 'music_room'
