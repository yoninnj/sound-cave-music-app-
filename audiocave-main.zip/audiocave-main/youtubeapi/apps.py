from django.apps import AppConfig


class YoutubeapiConfig(AppConfig):
    name = 'youtubeapi'
