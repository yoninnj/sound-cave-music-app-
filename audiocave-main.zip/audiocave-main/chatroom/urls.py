from django.urls import path
from . import views
from chatroom.views import *

urlpatterns = []
