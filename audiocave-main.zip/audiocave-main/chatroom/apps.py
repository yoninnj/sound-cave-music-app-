from django.apps import AppConfig


class ChatroomConfig(AppConfig):
    name = 'chatroom'
